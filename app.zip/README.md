### Установка расширения

* Сделать клон репозитория
* Перейти chrome://extensions/
* Включить опцию Developer mode
* Load unpacked extension...
