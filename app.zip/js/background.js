
// chrome.browserAction.setBadgeText({text: "0"});
// Called when the user clicks on the browser action.
chrome.browserAction.onClicked.addListener(function(tab) {
  // chrome.browserAction.setBadgeText({text: "0"});
});
